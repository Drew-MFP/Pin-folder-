package com.pinvault.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** The cover picture: your own photo, or the built-in one. */
final class Decoy {
    private Decoy() {}

    private static File file(Context c) {
        return new File(c.getFilesDir(), "cover_picture");
    }

    static boolean hasCustom(Context c) {
        return file(c).exists();
    }

    static void clearCustom(Context c) {
        //noinspection ResultOfMethodCallIgnored
        file(c).delete();
    }

    /** Copies a picked photo into the app's private storage. */
    static boolean saveFrom(Context c, Uri uri) {
        try (InputStream in = c.getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(file(c))) {
            if (in == null) return false;
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Loads the custom photo scaled to the screen and turned upright, or null to use the built-in picture. */
    static Bitmap load(Context c) {
        File f = file(c);
        if (!f.exists()) return null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), bounds);
            int target = Math.max(c.getResources().getDisplayMetrics().widthPixels,
                    c.getResources().getDisplayMetrics().heightPixels);
            int sample = 1;
            while (Math.max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= target) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            Bitmap bmp = BitmapFactory.decodeFile(f.getPath(), opts);
            if (bmp == null) return null;

            int rotate = 0;
            switch (new ExifInterface(f.getPath()).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                case ExifInterface.ORIENTATION_ROTATE_90: rotate = 90; break;
                case ExifInterface.ORIENTATION_ROTATE_180: rotate = 180; break;
                case ExifInterface.ORIENTATION_ROTATE_270: rotate = 270; break;
            }
            if (rotate != 0) {
                Matrix m = new Matrix();
                m.postRotate(rotate);
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
            }
            return bmp;
        } catch (Exception e) {
            return null;
        }
    }
}
