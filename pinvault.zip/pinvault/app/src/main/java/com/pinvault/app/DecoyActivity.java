package com.pinvault.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageView;

/**
 * What the app opens to: just a picture. Tap, tap, hold on it opens the PIN screen.
 * Wrong taps do nothing at all, so it looks like an ordinary picture.
 */
public class DecoyActivity extends Activity {

    private TapCode.Recorder recorder;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        // First run: create a PIN before anything else
        if (!Prefs.hasPin(this)) {
            startActivity(new Intent(this, PinActivity.class));
            finish();
            return;
        }

        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        ImageView img = new ImageView(this);
        img.setBackgroundColor(Color.BLACK);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        Bitmap custom = Decoy.load(this);
        if (custom != null) img.setImageBitmap(custom);
        else img.setImageResource(R.drawable.cover_default);

        recorder = new TapCode.Recorder(new TapCode.Recorder.Listener() {
            @Override public void onChange(String soFar) {
                // Unlock the moment the rhythm matches, no need to wait for the pause
                if (TapCode.matches(soFar)) {
                    recorder.reset();
                    startActivity(new Intent(DecoyActivity.this, PinActivity.class));
                    finish();
                }
            }
            @Override public void onDone(String code) { /* wrong rhythm: do nothing */ }
        });
        img.setOnTouchListener(recorder);

        setContentView(img);
    }

    @Override
    protected void onDestroy() {
        if (recorder != null) recorder.reset();
        super.onDestroy();
    }
}
