package com.pinvault.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** PIN screen: creates a PIN on first launch, then asks for it every time the vault opens. */
public class PinActivity extends Activity {
    static final String EXTRA_CHANGE = "change_pin";
    private static final int MIN_LEN = 4, MAX_LEN = 8;

    private final StringBuilder entry = new StringBuilder();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView title, dots, hint;
    private boolean settingPin;
    private String firstPin;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        // Hide contents from screenshots and the recent-apps preview
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        settingPin = !Prefs.hasPin(this) || getIntent().getBooleanExtra(EXTRA_CHANGE, false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Ui.BG);
        int pad = Ui.dp(this, 24);
        root.setPadding(pad, pad, pad, pad);

        title = Ui.text(this, "", 22, Ui.FG, true);
        dots = Ui.text(this, "", 30, Ui.ACCENT, true);
        dots.setLetterSpacing(0.35f);
        dots.setMinHeight(Ui.dp(this, 56));
        dots.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 4));
        hint = Ui.text(this, "", 14, Ui.MUTED, false);
        hint.setMinHeight(Ui.dp(this, 40));

        root.addView(title);
        root.addView(dots);
        root.addView(hint);
        root.addView(buildKeypad());
        setContentView(root);

        showPrompt(null);
        tickLockout();
    }

    private GridLayout buildKeypad() {
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        grid.setPadding(0, Ui.dp(this, 16), 0, 0);
        String[] keys = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "OK"};
        int size = Ui.dp(this, 76), margin = Ui.dp(this, 8);
        for (String k : keys) {
            TextView key = Ui.text(this, k, k.equals("OK") ? 18 : 26,
                    k.equals("OK") ? Ui.ACCENT : Ui.FG, k.equals("OK"));
            key.setBackground(Ui.round(Ui.SURFACE, size / 2f));
            key.setClickable(true);
            key.setOnClickListener(v -> press(k));
            if (k.equals("⌫")) {
                key.setOnLongClickListener(v -> { entry.setLength(0); updateDots(); return true; });
            }
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = size;
            lp.height = size;
            lp.setMargins(margin, margin, margin, margin);
            grid.addView(key, lp);
        }
        return grid;
    }

    private void press(String k) {
        if (!settingPin && Prefs.lockRemainingMs(this) > 0) return;
        if (k.equals("⌫")) {
            if (entry.length() > 0) entry.deleteCharAt(entry.length() - 1);
        } else if (k.equals("OK")) {
            submit();
            return;
        } else if (entry.length() < MAX_LEN) {
            entry.append(k);
        }
        updateDots();
    }

    private void submit() {
        if (entry.length() < MIN_LEN) {
            showPrompt("PIN must be 4–8 digits");
            return;
        }
        String pin = entry.toString();
        entry.setLength(0);
        updateDots();

        if (settingPin) {
            if (firstPin == null) {
                firstPin = pin;
                showPrompt(null);
            } else if (firstPin.equals(pin)) {
                Prefs.setPin(this, pin);
                Prefs.clearFails(this);
                Toast.makeText(this, "PIN saved", Toast.LENGTH_SHORT).show();
                openVault();
            } else {
                firstPin = null;
                showPrompt("PINs didn't match. Try again.");
            }
            return;
        }

        if (Prefs.checkPin(this, pin)) {
            Prefs.clearFails(this);
            openVault();
        } else if (Prefs.recordFail(this)) {
            tickLockout();
        } else {
            int left = Prefs.failsLeft(this);
            showPrompt("Wrong PIN. " + left + (left == 1 ? " try" : " tries") + " left.");
        }
    }

    private void showPrompt(String error) {
        if (settingPin) {
            title.setText(firstPin == null ? "Create a PIN" : "Confirm your PIN");
        } else {
            title.setText("Enter PIN");
        }
        if (error != null) {
            hint.setText(error);
            hint.setTextColor(Ui.ERROR);
        } else {
            hint.setText(settingPin && firstPin == null ? "4 to 8 digits" : "");
            hint.setTextColor(Ui.MUTED);
        }
    }

    private void tickLockout() {
        if (settingPin) return;
        long ms = Prefs.lockRemainingMs(this);
        if (ms > 0) {
            hint.setTextColor(Ui.ERROR);
            hint.setText("Too many tries. Wait " + ((ms + 999) / 1000) + "s");
            handler.postDelayed(this::tickLockout, 500);
        } else if (hint.getText().toString().startsWith("Too many")) {
            showPrompt(null);
        }
    }

    private void updateDots() {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < entry.length(); i++) s.append('●');
        dots.setText(s.toString());
    }

    private void openVault() {
        startActivity(new Intent(this, VaultActivity.class));
        finish();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
