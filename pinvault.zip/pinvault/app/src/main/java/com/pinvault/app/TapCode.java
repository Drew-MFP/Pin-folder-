package com.pinvault.app;

import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

/**
 * The secret on the cover picture: tap, tap, hold ("TTH").
 * A press shorter than HOLD_MS is a tap; longer is a hold. A pause of END_MS ends the sequence.
 */
final class TapCode {
    private TapCode() {}

    static final long HOLD_MS = 450;
    static final long END_MS = 1000;
    static final int MAX_LEN = 10;

    /** The secret: tap, tap, hold. */
    static final String CODE = "TTH";

    static boolean matches(String code) {
        return CODE.equals(code);
    }

    /** "TTH" -> "tap · tap · hold" */
    static String describe(String code) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < code.length(); i++) {
            if (i > 0) s.append("  ·  ");
            s.append(code.charAt(i) == 'H' ? "hold" : "tap");
        }
        return s.toString();
    }

    /** Turns touches on a view into a T/H sequence. */
    static class Recorder implements View.OnTouchListener {
        interface Listener {
            /** Called after every tap or hold with the sequence so far. */
            void onChange(String soFar);
            /** Called once the person pauses, with the finished sequence. */
            void onDone(String code);
        }

        private final Listener listener;
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final StringBuilder seq = new StringBuilder();
        private long downAt;
        private boolean down;

        private final Runnable finish = () -> {
            String code = seq.toString();
            seq.setLength(0);
            if (!code.isEmpty()) listener.onDone(code);
        };

        Recorder(Listener listener) {
            this.listener = listener;
        }

        void reset() {
            handler.removeCallbacks(finish);
            seq.setLength(0);
            down = false;
        }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    handler.removeCallbacks(finish);
                    downAt = e.getEventTime();
                    down = true;
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!down) return true;
                    down = false;
                    seq.append(e.getEventTime() - downAt >= HOLD_MS ? 'H' : 'T');
                    if (seq.length() > MAX_LEN) seq.deleteCharAt(0);
                    listener.onChange(seq.toString());
                    handler.postDelayed(finish, END_MS);
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    down = false;
                    handler.postDelayed(finish, END_MS);
                    return true;
                default:
                    return true;
            }
        }
    }
}
